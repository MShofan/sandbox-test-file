#!/bin/bash

wget https://www.eicar.org/download/eicar.com

# 2023-11-22 14:05:17.488690